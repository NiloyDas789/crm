<div class="row">
    @include('dashboard.application.profile')
    <div class="col-md-9">
        <div class="card card-body">
            <div class="row">
                <div class="col-4">
                    <div>
                        <h3>In Progress</h3>
                    </div>
                </div>
            </div>
            <hr />

            <div class="row">
                <div class="col-9">
                    <div class="row">
                        <div class="col-3">
                            <div>
                                <div>
                                    Course:
                                </div>
                                <div>
                                    {{$application->product->name}}
                                </div>
                            </div>
                            <div>
                                <div>
                                    Application Id:
                                </div>
                                <div>
                                    {{$application->id}}
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div>
                                <div>
                                    University:
                                </div>
                                <div>

                                </div>
                            </div>
                            <div>
                                <div>
                                    Parent's Client Id
                                </div>
                                <div>
                                    {{$application->client->name}}
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div>
                                <div>
                                    Branch:

                                </div>
                                <div>
                                    {{$application->branch->name}}

                                </div>
                            </div>
                            <div>
                                <div>
                                    Started At:

                                </div>
                                <div>
                                    {{$application->started_at}}

                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div>
                                <div>
                                    Workflow:

                                </div>
                                <div>
                                    {{$application->workflow->name}}

                                </div>
                            </div>
                            <div>
                                <div>
                                    Last Updated:

                                </div>
                                <div>
                                    {{$application->updated_at}}

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3"></div></div>
            <hr />

            <div class="row">
                <div class="col-9">
                    <ul class="nav nav-tabs nav-justified nav-tabs-custom" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#custom-activities" role="tab">
                                 <span class="d-none d-md-inline-block">Activities</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#custom-documents" role="tab">
                                 <span class="d-none d-md-inline-block">Documents</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#custom-notes" role="tab">
                                 <span class="d-none d-md-inline-block">Notes</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#custom-tasks" role="tab">
                                 <span class="d-none d-md-inline-block">Tasks</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#custom-schedules" role="tab">
                                 <span class="d-none d-md-inline-block">Payment Schedule</span>
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content p-3">
                        <div class="tab-pane active" id="custom-activities" role="tabpanel">
                            <p class="mb-0">
                                Food truck fixie locavore, accusamus mcsweeney's marfa nulla
                                single-origin coffee squid. Exercitation +1 labore velit, blog
                                sartorial PBR leggings next level wes anderson artisan four loko
                                farm-to-table craft beer twee. Qui photo booth letterpress,
                                commodo enim craft beer mlkshk aliquip jean shorts ullamco ad
                                vinyl cillum PBR. Homo nostrud organic, assumenda labore
                                aesthetic magna delectus mollit.
                            </p>
                        </div>
                        <div class="tab-pane" id="custom-documents" role="tabpanel">
                            <p class="mb-0">
                                Raw denim you probably haven't heard of them jean shorts Austin.
                                Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache
                                cliche tempor, williamsburg carles vegan helvetica. Reprehenderit
                                butcher retro synth. Cosby sweater eu banh mi,
                                qui irure terry richardson ex squid. Aliquip placeat salvia cillum
                                iphone. Seitan aliquip quis cardigan american apparel, butcher
                                voluptate nisi qui.
                            </p>
                        </div>
                        <div class="tab-pane" id="custom-notes" role="tabpanel">
                            <p class="mb-0">
                                Etsy mixtape wayfarers, ethical wes anderson tofu before they
                                sold out mcsweeney's organic lomo retro fanny pack lo-fi
                                farm-to-table readymade. Messenger bag gentrify pitchfork
                                tattooed craft beer, iphone skateboard locavore carles etsy
                                salvia banksy hoodie helvetica. DIY synth PBR banksy irony.
                                Leggings gentrify squid 8-bit cred pitchfork. Williamsburg banh
                                mi whatever gluten carles.
                            </p>
                        </div>
                        <div class="tab-pane" id="custom-tasks" role="tabpanel">
                            <p class="mb-0">
                                Trust fund seitan letterpress, keytar raw denim keffiyeh etsy
                                art party before they sold out master cleanse gluten-free squid
                                scenester freegan cosby sweater. Fanny pack portland seitan DIY,
                                art party locavore wolf cliche high life echo park Austin. Cred
                                vinyl keffiyeh DIY salvia PBR, banh mi before they sold out
                                farm-to-table VHS viral locavore cosby sweater. Lomo wolf viral,
                                mustache.
                            </p>
                        </div>
                        <div class="tab-pane" id="custom-schedules" role="tabpanel">
                            <p class="mb-0">
                                Trust fund seitan letterpress, keytar raw denim keffiyeh etsy
                                art party before they sold out master cleanse gluten-free squid
                                scenester freegan cosby sweater. Fanny pack portland seitan DIY,
                                art party locavore wolf cliche high life echo park Austin. Cred
                                vinyl keffiyeh DIY salvia PBR, banh mi before they sold out
                                farm-to-table VHS viral locavore cosby sweater. Lomo wolf viral,
                                mustache.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-3 "  style="border-left: 1px solid;opacity: .4;">
                    <div class="row">

                    </div>
                </div>
            </div>
        </div>
    </div>


</div>
