<div class="row">
    @include('dashboard.application.profile')
    <div class="col-md-9">
        <div class="card card-body">
            @include('dashboard.application.applicationTable')
        </div>
    </div>


</div>
