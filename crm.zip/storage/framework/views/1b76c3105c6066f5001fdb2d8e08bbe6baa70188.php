<table id="datatable" class="table table-striped  table-bordered table-responsive nowrap">
    <thead>
    <tr>
        <th><?php echo e(__('ID')); ?></th>
        <th><?php echo e(__('Name')); ?></th>
        <th><?php echo e(__('Tag')); ?></th>
        <th><?php echo e(__('Rating')); ?></th>
        <th><?php echo e(__('Client Id')); ?></th>
        <th><?php echo e(__('Number')); ?></th>
        <th><?php echo e(__('Passport Number')); ?></th>
        <th><?php echo e(__('Email')); ?></th>
        <th class="action"><?php echo e(__('Action')); ?></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($client->sl); ?></td>
            <td><a href="<?php echo e(route('application.index',$client->id)); ?>"><?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?> </a></td>
            <td><?php echo e($client->tag); ?></td>
            <td><?php echo e($client->rating); ?></td>
            <td><?php echo e($client->client_id); ?></td>
            <td><?php echo e($client->phone); ?></td>
            <td><?php echo e($client->passport_number); ?></td>
            <td><?php echo e($client->email); ?></td>
            <td nowrap="nowrap">
                
                
                <button onclick="editData(this)" type="button" class="btn btn-primary btn-md waves-effect waves-light"
                        data-bs-toggle="modal" data-bs-target="#edit<?php echo e($client->id); ?>"><i
                        class="fas fa-edit"></i></button>
                <!-- sample modal content -->
                <div id="edit<?php echo e($client->id); ?>" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog"
                     aria-labelledby="editLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editLabel">Edit Status</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                            </div>
                            <?php echo e(Form::model($client, ['route' => ['client.update', $client->id], 'method' => 'PUT', 'class' => 'needs-validation', 'novalidate'])); ?>

                            <div class="modal-body">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php echo $__env->make('dashboard.client.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary waves-effect"
                                        data-bs-dismiss="modal">Close</button>
                                <button type="submit"
                                        class="btn btn-primary waves-effect waves-light">Update</button>
                            </div>
                            <?php echo e(Form::close()); ?>

                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                <?php echo e(Form::open(['method' => 'DELETE', 'route' => ['client.destroy', $client->id], 'style' => 'display:inline'])); ?>

                <?php echo e(Form::button('<i class="fas fa-trash"  aria-hidden="true"></i>', ['class' => 'btn btn-danger btm-md', 'type' => 'submit'])); ?>

                <?php echo e(Form::close()); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH E:\laragon\www\crm\resources\views/dashboard/client/clientTable.blade.php ENDPATH**/ ?>