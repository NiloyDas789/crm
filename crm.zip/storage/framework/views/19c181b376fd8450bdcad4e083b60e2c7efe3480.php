<div class="col-md-3">
    <div class="card card-body">
        <div class="text-center">
            <div class="mb-3">
                <img class="rounded-circle" src="<?php echo e(asset('assets/images/users/avatar-1.jpg')); ?>">
            </div>
            <div>
                <h1><?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?></h1>
            </div>
            <hr />
            <div class="text-start d-grid gap-3 fs-4">
                <div><h2>Personal Details:</h2></div>
                <div>
                    <div>Tag(s):</div>
                    <div>-</div>
                </div>
                <div>
                    <div>Added From:</div>
                    <div>-</div>
                </div>
                <div>
                    <div>Client Id:</div>
                    <div><?php echo e($client->client_id); ?></div>
                </div>
                <div>
                    <div>Internal Id:</div>
                    <div><?php echo e($client->id); ?></div>
                </div>
                <div>
                    <div>Date of Birth:</div>
                    <div><?php echo e($client->dob); ?></div>
                </div>
                <div>
                    <div>Phone Number:</div>
                    <div><?php echo e($client->phone); ?></div>
                </div>
                <div>
                    <div>Email:</div>
                    <div><?php echo e($client->email); ?></div>
                </div>
                <div>
                    <div>Address:</div>
                    <div><?php echo e($client->street); ?>,<?php echo e($client->city->state->country->name); ?></div>
                </div>
                <div>
                    <div>Visa Expiry:</div>
                    <div><?php echo e($client->street); ?>,<?php echo e($client->city->state->country->name); ?></div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH E:\laragon\www\crm\resources\views/dashboard/application/profile.blade.php ENDPATH**/ ?>